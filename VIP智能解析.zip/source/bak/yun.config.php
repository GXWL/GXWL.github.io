<?php
$YUN_CONFIG=array (
  'API' => 
  array (
    0 => '源1=>https://api.iokzy.com/inc/ldg_seackm3u8s.php',
    1 => '源2=>http://www.zdziyuan.com/inc/s_ldgm3u8_sea.php',
    2 => '源3=>http://cj.809zy.com/inc/seacmsapi.php',
  ),
  'name_filter' => '激情|写真|成人|福利',
  'flag_filter' => '',
  'jmp_off' => '1',
  'flag_replace' => 
  array (
    'ckm3u8' => '源1',
    'zuidam3u8' => '源2',
  ),
  'url_filter' => '',
);
