<?php
$YUN_CONFIG=array (
  'API' => 
  array (
    0 => '线路1=>http://api.iokzy.com/inc/apickm3u8.php',
    1 => '线路2=>http://cj.wlzy.tv/inc/api_mac_m3u8.php',
  ),
  'name_filter' => '激情|写真|成人|福利',
  'flag_filter' => '',
  'jmp_off' => '1',
  'flag_replace' => 
  array (
    'ckm3u8' => '源1',
    'zuidam3u8' => '源2',
  ),
  'url_filter' => '',
);
